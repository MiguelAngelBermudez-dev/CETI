# Practica 1 Bastionado

## Realizado por Miguel Angel Bermudez Cote

### Indice:

- [**site:pastebin.com ‘key windows11’**](#**1.-site:pastebin.com-‘key windows11’** )
- [**site:github.com 'default credential routers tplink' OR 'list credential tplink' OR 'library credential tplink’**](#**2.-site:github.com-'default-credential-routers-tplink'-OR 'list-credential-tplink'-OR-'library-credential-tplink’**)
- [site:pastebin.com intext:'facebook password leak’](#3.-site:pastebin.com-intext:'facebook-password-leak’)
- [site:navantia.es filetype:pdf'empleados ‘](#4.-site:navantia.es-filetype:pdf'empleados‘)
- [site:futbollibre.mx](#5.-site:futbollibre.mx)

# objetivos

En esta practica usaremos google dorking para realizar busqueda de datos avanzadas de leaks filtraciones de informacion que estan accesibles en la web como en paginas como [pastebin.com](http://pastebin.com), re4alizaremos 5 busquedas de filtraciones utilizando diferentes tecnicas de busqueda avanzada y las explicare paso a paso 

### **1. site:pastebin.com ‘key windows11’**

- resultado:como podemos ver en la captura de abajo hemos encontrado una filtracion de claves de windows 11 pro para activar el producto usando la sintaxis de busqueda avanzada ‘site:’
Limita la búsqueda únicamente a un **dominio o sitio web específico**.
y las comillas ‘’ 
Fuerza a Google a buscar la **frase exacta** o la secuencia de palabras tal como fue escrita, sin variaciones o sinónimos. De esta forma hemos encontrado el primer enlace: [https://pastebin.com/AYW6CD2n](https://pastebin.com/AYW6CD2n)

![image.png](image.png)

### **2. site:github.com 'default credential routers tplink' OR 'list credential tplink' OR 'library credential tplink’**

- En esta busqueda lo que he querido indicar es que en repositorios github busque credenciales de los direfentes routers tplink indicando la condicon OR para realizar varias busquedas de diferente informacion

![image.png](image%201.png)

### 3.site:pastebin.com intext:'facebook password leak’

En esta busqueda avanzada podemos ver la sintaxis intext que indica que me busque en el sitio web indicado lo que contenga ya sea titulo o cuerpo de pagina. En la imagen podemos ver una filtracion de cuentas de facebook con sus corespondientes contraseñas

![image.png](image%202.png)

### 4. site:navantia.es filetype:pdf'empleados ‘

con esta sintaxis filetype:pdf ‘empleados’ sirve para obtener pdf del sitio web lo cual he encontrado un pdf con nombre y cargos de los empleados de navantia 

![image.png](image%203.png)

### 5. site:futbollibre.mx

Con esta sintaxis en encontrado una pagina la cual transmite partidos de futbol en directo 

![image.png](image%204.png)